# Phase 1 — Root-cause report (voice, AI & runtime)

Scope: read-only audit of the uploaded `jarvis-repairs-mark-lv` source plus reproductions that were possible on a Linux sandbox (Python 3.12.3, no audio hardware, no Google account, no Windows). **No application behaviour was changed in Phase 1.** Only investigation tooling was added (`tools/phase1_probe.py`, `tools/phase1_repro_error_order.py`) and these documents.

Evidence labels used below:

* **VERIFIED** — read in source and/or reproduced by running code.
* **STRONG INFERENCE** — follows from verified code, but the final behaviour needs a live Windows/account run.
* **HYPOTHESIS** — plausible cause that cannot be confirmed without the user's machine. Do not "fix" these blindly; collect evidence first (see §6).

Baseline: `python -m unittest discover -s tests` → 83 tests, all pass. **None of them exercise the voice path** (wake word, PTT, mic loop, state, error handler, STT/TTS). `tools/diagnostics.py --audio` only checks module presence and device counts. So "83 passing" says nothing about whether Jarvis can hear or speak.

---

## 1. Architecture facts that change the scope of the repair

| # | Fact | Evidence | Consequence |
|---|---|---|---|
| A1 | **STT, TTS and intent routing are all done inside Gemini Live.** Mic PCM goes to `session.send_realtime_input`; `input_audio_transcription` is the STT; the model's native audio is the TTS; Gemini function-calling is the intent router. | `main.py` `_build_config` (≈L1065), `_send_realtime`, `_play_audio` | There is no local STT→router→TTS pipeline to "repair". |
| A2 | `core/stt.py`, `core/tts.py`, `core/llm_client.py` are **dead code**: nothing imports them. | `grep` over all `*.py`: zero importers outside the files themselves | Master-prompt items "Test Voice without an API key", "local TTS fallback", "independent local commands when Gemini is down", "local STT for Hindi/Hinglish" are **new builds**, not repairs. `REPAIR_STATUS.md` finding 10 already lists offline conversation as *unresolved*. |
| A3 | The whole assistant lives in one `asyncio.TaskGroup` opened *after* `client.aio.live.connect()` succeeds: mic, speaker, receive, send, system monitor, background monitor, proactive, sleep watch, dashboard relay (12 tasks). | `main.py` ≈L2185–2250 | Any failing task (even optional ones) cancels the session **and the microphone**. If connect fails, the mic is never opened at all. |

## 2. Verified root causes, mapped to the 12 observed problems

### RC-1 — Reconnect handler classifies errors by substring, in the wrong order (VERIFIED, reproduced)
`main.py` ≈L2268–2372. Reproduction: `python tools/phase1_repro_error_order.py` feeds a real `google.genai.errors.ClientError` for a bad key (`400 INVALID_ARGUMENT … API key not valid`) through the handler's branch order:

```
attempt 1: tuned_live -> disabled silently, reconnect
attempt 2: LOG 'Proactive audio unavailable'
attempt 3: LOG 'API key invalid'
```

This is **exactly the order of your log** (`Proactive audio unavailable` → `API key invalid`). Gemini reports a bad key as `INVALID_ARGUMENT`, and the two feature-downgrade branches match `INVALID_ARGUMENT` first. Further defects in the same block:

1. **State poisoning.** `_tuned_live` and `_enhanced_live` are set to `False` for the rest of the process and never restored, even after the user fixes the key. Turn-tuning and proactive audio are silently lost. (Problem 11.)
2. **`"1007" in err_str` is treated as "bad key".** WebSocket close code 1007 means *invalid payload data*. The repo's own comment at `_send_realtime` says Gemini 3.x closes with 1007 when it dislikes a field. So a **valid key plus a rejected setup field/model/API-version can be shown as "API key invalid"**. Your key may be fine. (Problem 7. STRONG INFERENCE; the probe's `--provider` mode separates the cases.)
3. **Exceptions raised inside the TaskGroup are invisible to the classifier.** `str(BaseExceptionGroup)` is just `unhandled errors in a TaskGroup (1 sub-exception)`; the underlying cause is never inspected. Reproduced: a microphone/speaker open failure falls through every branch to a **silent 3-second reconnect loop** with only a console traceback. (Problems 2, 3, 4.)
4. **`"OSError"` / `"CancelledError"` substrings are treated as network failures and the log always says "(a VPN may be required)".** TLS, proxy, audio-device and file errors are all mislabelled. (Problem 8.)
5. **Typo:** the invalid-key branch assigns a local `_conn_backoff = 3`, not `self._conn_backoff`, so the intended reset never happens.
6. Network branch backs off to 60 s but **never gives up and never surfaces a persistent error state**.

### RC-2 — Microphone only exists while a cloud session exists (VERIFIED)
`_listen_audio` is created inside the `async with live.connect(...)` block. With a bad key/network failure the mic stream is never opened → no level meter, no PTT capture, no way to test hearing. If opening the chosen *or default* device raises (`if _mic_dev is None: raise`, same for the speaker in `_play_audio`), the exception kills the TaskGroup and re-enters RC-1's silent loop. (Problems 2, 3, 6, 12.)

### RC-3 — "SLEEPING" is a free-form string written from many places, not a state (VERIFIED)
`ui.set_state(str)` just emits a signal; `hud.state` is the only record. Four independent sources produce `SLEEPING`:

| Source | Location | Effect |
|---|---|---|
| End of **every** reconnect-loop iteration | `main.py` ≈L2385 | any connection failure shows SLEEPING |
| Invalid-key branch | ≈L2352 | SLEEPING while the key dialog is open |
| **PTT release** | `_on_ptt` ≈L937: `set_state("LISTENING" if held else "SLEEPING")` | every key release forces SLEEPING, regardless of wake-word mode or connection |
| Real wake gating | `sleep()` / startup when `wake_word_enabled` | intended behaviour |

Real state is split across unsynchronised flags: `_awake`, `_is_speaking`, `_ptt_held`, `ui.muted`, `_phone_active`. The HUD vocabulary has only LISTENING / THINKING / SPEAKING / MUTED / SLEEPING (`ui.py` `_apply_state`): no ERROR, RECONNECTING, MIC_UNAVAILABLE, PROVIDER_UNAVAILABLE. (Problems 1, 10.)

### RC-4 — "Online" is a hard-coded message (VERIFIED)
`ui.py` `_on_setup_done` (≈L5620–5626) logs `SYS: Initialised. OS=…. JARVIS online.` and sets LISTENING **when the key dialog is saved**, before any connection attempt. The genuine post-connect message in `main.py` is `SYS: JARVIS online.` / `…online — sleeping…`, and **it never appears in your log**. So in the captured run **no Live session was ever established**, which also means the mic and speaker were never started. (Problem 12; STRONG INFERENCE for the "never connected" part.)

### RC-5 — Sleeping can be a permanent dead end when wake word is enabled but unusable (VERIFIED)
On startup with `wake_word_enabled=True`, `_ensure_wake_detector()` is called and **its return value is ignored**; `_awake=False` and the mic is gated. If the model failed to load, nothing is listening and nothing wakes the app except the WAKE NOW button or PTT. There is no "Start Listening" button when wake word is off. Auto-sleep is hard-coded to 120 s (`WAKE_SLEEP_TIMEOUT`), not the configurable 30 s follow-up window. (Problems 1, 5. Whether your config has `wake_word_enabled=true` is unknown; the probe prints it.)

### RC-6 — Push-to-talk gating can never finalize a turn (STRONG INFERENCE) and is easy to miss
* The mic callback sends nothing while PTT is enabled and the chord isn't held. If `push_to_talk_enabled` is persisted (your log shows PTT on), **nothing reaches Gemini unless Ctrl+Space is physically held**.
* **No `audio_stream_end` and no manual activity signals exist anywhere in the repo** (`grep` = 0 hits). With server-side automatic VAD, closing the gate means no trailing-silence audio and no end-of-stream marker; the server may never decide your turn ended. This needs one live test but is the leading suspect for "I held the key, spoke, nothing came back".
* `_on_ptt` clobbers HUD state (RC-3).
* Ctrl+Space is polled with `GetAsyncKeyState` (does not consume the key), so apps that use Ctrl+Space (VS Code suggestions, some IME layouts) still react to it. Not a code defect, a conflict risk. (Problem 6.)

### RC-7 — Wake word: wrong phrase, fragile installer, no recovery (VERIFIED + HYPOTHESES)
* **VERIFIED:** the only pretrained model used is `hey_jarvis` → phrase is **"Hey Jarvis"**, not "Jarvis". The code and UI text say "Hey Jarvis" honestly. The master prompt's "Jarvis" is **not supported by any model in this repo**. Do not substitute silently.
* **VERIFIED:** `core/wake_word.py::install_and_download` runs `sys.executable -m pip install openwakeword` at runtime and keeps only the last 160 chars of the last stderr line, so the real pip failure reason is discarded. It also contradicts the "no runtime pip" policy in `core/installer.py`/`REPAIR_STATUS.md` (documented there as an explicit-opt-in exception).
* **VERIFIED:** `is_installed()` is just `find_spec`, so a **partially installed** package counts as installed; the second attempt skips pip and calls `openwakeword.utils.download_models`, which is where `[WinError 183]` appeared (creating `…\.venv\Lib\site-packages\openwakeword\resources\models`).
* **HYPOTHESES for WinError 183 (rank unknown until probed):** (a) the `.venv` is inside a **OneDrive-synced Desktop folder**, and sync/Files-On-Demand reparse state makes `exists()` and `mkdir()` disagree; (b) a partial install from the first failed pip run left a conflicting entry; (c) two overlapping download clicks. The probe prints `lexists/isdir/isfile/islink` and Windows file attributes for that path.
* **HYPOTHESIS for "pip install failed":** cannot be determined from the log. `pip install --dry-run openwakeword` via the probe will show the true reason (dependency resolution vs. a build step vs. permissions vs. network).
* Smaller issues: `stop()` sets `_model=None` while the worker thread may still call `predict` (error spam); `DEFAULT_THRESHOLD=0.5` is not user-configurable; no acknowledgement sound; 1024-sample callback blocks versus the library's 80 ms framing is unverified.

### RC-8 — Diagnostics and tests do not cover the voice path (VERIFIED)
No frame-capture test, no TTS/playback test, no wake-word initialization, no state-machine test, no provider error classification, no stop/cancel test, no resource-cleanup test (0 of the 20 checks in master prompt §15 beyond module/device presence). Hardware cannot be PASS from mocks; none exists yet.

## 3. Problem-to-cause matrix

| # | Observed problem | Verified cause(s) | Still needs live evidence |
|---|---|---|---|
| 1 | Repeatedly SLEEPING | RC-3 (reconnect loop, key branch, PTT release), RC-5 | whether `wake_word_enabled` is true |
| 2 | Mic input not detected | RC-2 (mic only exists inside a connected session), RC-1.3 (mic failure silent) | Windows mic permission/device state |
| 3 | Commands not understood/executed | no session (RC-4); no local router (A2) | – |
| 4 | No speech through speakers | no session → `_play_audio` never started (RC-2/RC-4) ; playback path itself untested | speaker test on hardware |
| 5 | Wake word unreliable/unavailable | RC-7, RC-5 | pip failure reason, OneDrive state |
| 6 | PTT unconfirmed | RC-6, RC-2 | live press/release + reply test |
| 7 | Auth fails | RC-1.1/1.2 (misclassification); genuine bad key possible | REST vs Live probe result |
| 8 | Reconnect fails repeatedly | RC-1.4/1.6 (mislabel, no give-up) | DNS/TLS/proxy probe |
| 9 | Wake install/model download fails | RC-7 | probe |
| 10 | HUD can't distinguish states | RC-3 | – |
| 11 | Proactive audio unavailable | RC-1.1 (key error misread + flag poisoning) | – |
| 12 | Reports online when broken | RC-4 | – |

## 4. What is *not* wrong (checked)

* `google-genai==2.29.0` **exists on PyPI** and installs/imports on Python 3.12 (installed here). Pin is not the problem. The Live model name `models/gemini-3.1-flash-live-preview` could not be verified (no provider access from this sandbox); it is the only entry in `LIVE_MODELS` (no fallback ladder after the previous repair).
* Device enumeration/resolution code (`core/audio_devices.py`) is substantial and falls back to the default device on a bad saved device. Mic/speaker *open* failures on the default device are what escape (RC-2).
* Credential storage design (DPAPI + `$credential` references) is coherent. Whether the DPAPI read succeeds on your account is unverified (the probe checks that the `.dpapi` file exists, not that it decrypts, to stay read-only).

## 5. Not reproducible in the sandbox (needs your Windows machine)

Windows microphone privacy permission, WASAPI/MME behaviour, OneDrive file states, real `GetAsyncKeyState` polling, DPAPI decryption, real Live API behaviour (key vs model vs 1007), pip behaviour on your interpreter, audible speech.

## 6. Evidence to collect before Phase 2 (one command)

From the project folder in PowerShell:

```powershell
.\.venv\Scripts\python.exe tools\phase1_probe.py --mic-test 5 --speaker-test --hotkey-test --pip-dry-run --provider
```

Speak during the 5 s mic test, press Ctrl+Space during the hotkey test, say whether you heard the tone. `--pip-dry-run` and `--provider` use the internet; `--provider` sends only your key to Google (REST `models.list` and a Live connect that sends no audio) and classifies the result by exception type/code. Output: `phase1_evidence.json` (no credentials). Attach it to the next session. Without it, RC-7 and RC-1.2 stay hypotheses.

## 7. Limits of this phase

* No hardware, Windows or account test was possible, so **nothing here is a PASS for hearing, speaking, wake word, PTT or provider access**.
* `tools/phase1_repro_error_order.py` replays the handler's *branch order* with real SDK exceptions; it does not import `main.py` because the handler is inline in `JarvisLive.run()`. Re-verify if that code moves.
* `tools/phase1_probe.py` was run on Linux only (graceful FAIL/SKIPPED output verified); its Windows-only branches (file attributes, `GetAsyncKeyState`) are untested on Windows.
