# Phase 1 reproduction: replays the branch ORDER of main.py reconnect handler against real SDK errors.
# Not an import of main.py (the handler is inline in JarvisLive.run); re-verify if that code moves.
"""Replays the exact branch ORDER of main.py's reconnect handler (lines ~2268-2372)
against real google-genai exception objects. No network, no key."""
from google.genai import errors

def classify_like_main(e, tuned=True, enhanced=True):
    err_str = str(e)
    steps = []
    if tuned and ("INVALID_ARGUMENT" in err_str or "Unknown name" in err_str
                  or "unexpected keyword" in err_str or "realtime_input" in err_str.lower()
                  or "media_resolution" in err_str.lower() or "thinking" in err_str.lower()):
        steps.append("tuned_live -> disabled silently, reconnect")
        tuned = False
        return steps, tuned, enhanced
    if enhanced and ("INVALID_ARGUMENT" in err_str or "proactiv" in err_str.lower()
                     or "Unknown name" in err_str or "unexpected keyword" in err_str):
        steps.append("LOG 'Proactive audio unavailable'")
        return steps, tuned, False
    if "API key not valid" in err_str or "1007" in err_str:
        steps.append("LOG 'API key invalid'")
        return steps, tuned, enhanced
    if any(k in err_str for k in ("TimeoutError","timed out","getaddrinfo","CancelledError",
                                  "ConnectionRefusedError","OSError","Cannot connect")):
        steps.append("LOG 'NET: Connection failed ... (a VPN may be required)'")
        return steps, tuned, enhanced
    steps.append("no branch matched -> silent 3s retry")
    return steps, tuned, enhanced

bad_key = errors.ClientError(400, {"error": {"code": 400,
    "message": "API key not valid. Please pass a valid API key.", "status": "INVALID_ARGUMENT"}})
print("str(e) =", str(bad_key)[:120])
tuned, enh = True, True
for attempt in range(1, 4):
    steps, tuned, enh = classify_like_main(bad_key, tuned, enh)
    print(f"attempt {attempt}: {steps}")

print("\n-- ExceptionGroup from a TaskGroup child (e.g. receive loop gets WS close) --")
eg = BaseExceptionGroup("unhandled errors in a TaskGroup", [OSError("[Errno 11001] getaddrinfo failed")])
print("str(eg) =", str(eg))
print(classify_like_main(eg)[0])
eg2 = BaseExceptionGroup("unhandled errors in a TaskGroup", [Exception("sounddevice PortAudioError: Error opening InputStream")])
print("mic failure inside TaskGroup ->", classify_like_main(eg2)[0])
