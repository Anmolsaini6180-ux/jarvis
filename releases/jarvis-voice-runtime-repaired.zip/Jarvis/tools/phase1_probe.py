"""Phase 1 evidence collector for the Jarvis / Mark-LV voice repair.

Purpose
-------
The Phase 1 root-cause report separates *verified* findings (reproduced from the
source on Linux) from *hypotheses* that can only be confirmed on the user's real
Windows machine. This script gathers that missing evidence.

Safety
------
* Read-only by default. It never installs packages, never writes configuration,
  never deletes anything and never prints a credential.
* Everything that touches hardware, the network or a cloud account is OPT-IN:
    --mic-test SECONDS      open the microphone locally and measure levels
    --speaker-test          play a short tone through the default output
    --hotkey-test           watch Ctrl+Space for 6 seconds (Windows only)
    --pip-dry-run           `pip install --dry-run openwakeword` (needs internet)
    --provider              contact Google with YOUR configured key (no audio sent)
* Output: a table on screen and `phase1_evidence.json` in the current directory.

Status vocabulary: PASS / FAIL / SKIPPED / INFO / NEEDS_HUMAN.
Hardware checks are never PASS on their own: a speaker test can only be
NEEDS_HUMAN, because only a person can confirm they heard it.

Run (Windows PowerShell, from the project folder):
    .\\.venv\\Scripts\\python.exe tools\\phase1_probe.py --mic-test 5 --speaker-test
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.metadata
import importlib.util
import json
import os
import platform
import socket
import ssl
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

RESULTS: list[dict] = []


def record(section: str, check: str, status: str, detail: str = "", **extra) -> None:
    row = {"section": section, "check": check, "status": status, "detail": detail}
    row.update(extra)
    RESULTS.append(row)
    print(f"[{status:<11}] {section}: {check}" + (f" — {detail}" if detail else ""))


def _short(text: str, limit: int = 220) -> str:
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


# ── 1. Environment ──────────────────────────────────────────────────────────
def check_environment() -> None:
    record("env", "python", "INFO", f"{platform.python_version()} on {platform.platform()}")
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    record("env", "running inside a virtual environment", "PASS" if in_venv else "FAIL",
           sys.prefix)
    path_l = str(ROOT).lower()
    synced = "onedrive" in path_l
    record("env", "project folder is OneDrive-synced", "INFO",
           "YES — OneDrive Files-On-Demand/sync can interfere with package directories "
           "inside .venv (suspected WinError 183 cause; unconfirmed)" if synced else "no",
           onedrive=synced, project=str(ROOT))
    proxies = [k for k in ("HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY", "https_proxy", "http_proxy")
               if os.environ.get(k)]
    record("env", "proxy environment variables set (names only)", "INFO",
           ", ".join(proxies) or "none")


# ── 2. Wake word ────────────────────────────────────────────────────────────
_WIN_ATTRS = {
    0x400: "REPARSE_POINT",
    0x1000: "OFFLINE",
    0x40000: "RECALL_ON_OPEN",
    0x400000: "RECALL_ON_DATA_ACCESS",
    0x80000: "PINNED",
    0x100000: "UNPINNED",
}


def _win_attributes(path: Path) -> list[str]:
    if os.name != "nt":
        return []
    try:
        import ctypes
        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        if attrs == 0xFFFFFFFF:
            return ["<GetFileAttributes failed>"]
        return [name for bit, name in _WIN_ATTRS.items() if attrs & bit]
    except Exception as exc:  # pragma: no cover - Windows only
        return [f"<error {type(exc).__name__}>"]


def check_wake_word(pip_dry_run: bool) -> None:
    spec = importlib.util.find_spec("openwakeword")
    if spec is None or not spec.origin:
        record("wake", "openwakeword importable", "FAIL", "package not installed in this interpreter")
    else:
        try:
            version = importlib.metadata.version("openwakeword")
        except Exception:
            version = "unknown"
        record("wake", "openwakeword importable", "PASS", f"version {version}")
        models = Path(spec.origin).resolve().parent / "resources" / "models"
        record("wake", "models path state", "INFO",
               f"{models}  lexists={os.path.lexists(models)} isdir={models.is_dir()} "
               f"isfile={models.is_file()} islink={models.is_symlink()} "
               f"win_attrs={_win_attributes(models) or 'none'}",
               models_path=str(models))
        if models.is_dir():
            names = sorted(p.name for p in models.iterdir())
            record("wake", "model files present", "INFO", ", ".join(names) or "(empty)")
            jarvis = [n for n in names if "jarvis" in n.lower()]
            record("wake", "a 'jarvis' model file exists", "PASS" if jarvis else "FAIL",
                   ", ".join(jarvis) or "none")
            # Name check only: does NOT prove the phrase 'Jarvis' alone is recognised.
            record("wake", "phrase actually supported", "INFO",
                   "pretrained model is 'hey_jarvis' (phrase 'Hey Jarvis'); "
                   "plain 'Jarvis' is NOT a pretrained phrase")
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "--version"], capture_output=True,
                           text=True, timeout=30)
        record("wake", "pip available in this interpreter",
               "PASS" if r.returncode == 0 else "FAIL", _short(r.stdout or r.stderr))
    except Exception as exc:
        record("wake", "pip available in this interpreter", "FAIL", type(exc).__name__)

    if not pip_dry_run:
        record("wake", "pip install --dry-run openwakeword", "SKIPPED", "use --pip-dry-run")
        return
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--dry-run",
                            "--disable-pip-version-check", "openwakeword"],
                           capture_output=True, text=True, timeout=300)
        tail = (r.stderr or r.stdout).strip().splitlines()[-12:]
        record("wake", "pip install --dry-run openwakeword",
               "PASS" if r.returncode == 0 else "FAIL",
               _short(" | ".join(tail), 900), returncode=r.returncode)
    except Exception as exc:
        record("wake", "pip install --dry-run openwakeword", "FAIL", type(exc).__name__)


# ── 3. Audio ────────────────────────────────────────────────────────────────
def _import_sd():
    try:
        import sounddevice as sd  # noqa: WPS433
        return sd, None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {_short(exc)}"


def check_audio(mic_seconds: float, mic_device, speaker_test: bool) -> None:
    sd, err = _import_sd()
    if sd is None:
        record("audio", "sounddevice/PortAudio import", "FAIL", err)
        return
    record("audio", "sounddevice/PortAudio import", "PASS", sd.__version__)
    try:
        devices = sd.query_devices()
        apis = [a["name"] for a in sd.query_hostapis()]
        record("audio", "host APIs", "INFO", ", ".join(apis))
        default_in, default_out = sd.default.device
        rows = []
        for idx, d in enumerate(devices):
            rows.append({"index": idx, "name": d["name"], "in": d["max_input_channels"],
                         "out": d["max_output_channels"],
                         "rate": d["default_samplerate"], "hostapi": apis[d["hostapi"]]})
        n_in = sum(1 for r in rows if r["in"] > 0)
        n_out = sum(1 for r in rows if r["out"] > 0)
        record("audio", "input devices enumerated", "PASS" if n_in else "FAIL", f"{n_in} found")
        record("audio", "output devices enumerated", "PASS" if n_out else "FAIL", f"{n_out} found")
        record("audio", "default input / output index", "INFO", f"{default_in} / {default_out}",
               devices=rows)
    except Exception as exc:
        record("audio", "device enumeration", "FAIL", f"{type(exc).__name__}: {_short(exc)}")
        return

    if mic_seconds > 0:
        _mic_test(sd, mic_seconds, mic_device)
    else:
        record("audio", "microphone frame capture", "SKIPPED", "use --mic-test SECONDS")
    if speaker_test:
        _speaker_test(sd)
    else:
        record("audio", "speaker playback", "SKIPPED", "use --speaker-test")


def _mic_test(sd, seconds: float, device) -> None:
    import numpy as np
    chunks: list = []
    statuses: list[str] = []

    def callback(indata, frames, time_info, status):
        if status:
            statuses.append(str(status))
        chunks.append(indata.copy())

    # Same parameters main.py uses: 16 kHz, mono, int16, 1024-frame blocks.
    try:
        print(f"   …recording {seconds:g}s from the microphone — please speak normally")
        with sd.InputStream(samplerate=16000, channels=1, dtype="int16", blocksize=1024,
                            device=device, callback=callback):
            time.sleep(seconds)
    except Exception as exc:
        record("audio", "microphone frame capture (16 kHz mono int16, as main.py)", "FAIL",
               f"{type(exc).__name__}: {_short(exc)}")
        return
    if not chunks:
        record("audio", "microphone frame capture", "FAIL", "stream opened but delivered 0 frames")
        return
    data = np.concatenate(chunks).astype("float64").ravel()
    peak = int(np.max(np.abs(data)))
    rms = float(np.sqrt(np.mean(data ** 2)))
    nonzero = float(np.count_nonzero(data)) / data.size
    status = "PASS" if peak > 0 else "FAIL"
    record("audio", "microphone frame capture (16 kHz mono int16, as main.py)", status,
           f"{len(chunks)} blocks, peak={peak}/32767, rms={rms:.0f}, nonzero={nonzero:.1%}, "
           f"driver_status={sorted(set(statuses)) or 'clean'}",
           peak=peak, rms=rms)
    if peak > 0:
        record("audio", "was speech actually audible in the capture", "NEEDS_HUMAN",
               "peak≥2000 suggests normal speech; a flat/near-zero peak means a muted or "
               "permission-blocked microphone" + (" (peak is LOW)" if peak < 2000 else ""))


def _speaker_test(sd) -> None:
    import numpy as np
    rate = 24000  # same rate main.py plays Gemini audio at
    t = np.linspace(0, 0.6, int(rate * 0.6), endpoint=False)
    tone = (0.25 * np.sin(2 * np.pi * 440 * t) * 32767).astype("int16")
    try:
        print("   …playing a 0.6 s tone on the default output device")
        with sd.RawOutputStream(samplerate=rate, channels=1, dtype="int16", blocksize=1024) as out:
            out.write(tone.tobytes())
            time.sleep(0.3)
        record("audio", "speaker playback (24 kHz mono int16, as main.py)", "NEEDS_HUMAN",
               "stream opened and written without error; ONLY a human can confirm it was heard")
    except Exception as exc:
        record("audio", "speaker playback (24 kHz mono int16, as main.py)", "FAIL",
               f"{type(exc).__name__}: {_short(exc)}")


# ── 4. Hotkey ───────────────────────────────────────────────────────────────
def check_hotkey(enabled: bool) -> None:
    if os.name != "nt":
        record("hotkey", "Ctrl+Space global polling", "SKIPPED", "Windows only")
        return
    if not enabled:
        record("hotkey", "Ctrl+Space press/release observed", "SKIPPED", "use --hotkey-test")
        return
    import ctypes
    user32 = ctypes.windll.user32
    print("   …for 6 seconds, press and release Ctrl+Space a couple of times")
    seen_down = seen_up = False
    was_down = False
    end = time.monotonic() + 6
    while time.monotonic() < end:
        down = bool(user32.GetAsyncKeyState(0x11) & 0x8000) and bool(user32.GetAsyncKeyState(0x20) & 0x8000)
        if down and not was_down:
            seen_down = True
        if was_down and not down:
            seen_up = True
        was_down = down
        time.sleep(1 / 30)
    ok = seen_down and seen_up
    record("hotkey", "Ctrl+Space press AND release observed by the same polling API main.py uses",
           "PASS" if ok else "FAIL",
           f"down={seen_down} up={seen_up}. If FAIL: another app/IME may be consuming Ctrl+Space "
           "(note this checks key STATE only, not that audio is captured or a command dispatched)")


# ── 5. Credentials (structure only) ─────────────────────────────────────────
def check_credentials() -> None:
    cfg = ROOT / "config" / "api_keys.json"
    if not cfg.exists():
        record("creds", "config/api_keys.json", "FAIL", "file missing")
        return
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
    except Exception as exc:
        record("creds", "config/api_keys.json readable", "FAIL", type(exc).__name__)
        return
    key = data.get("gemini_api_key")
    if isinstance(key, dict) and "$credential" in key:
        kind = "protected reference ($credential)"
        store = ROOT / "config" / "credentials"
        files = list(store.glob("*.dpapi")) if store.is_dir() else []
        record("creds", "protected credential file on disk", "PASS" if files else "FAIL",
               f"{len(files)} .dpapi file(s) in config/credentials")
    elif isinstance(key, str) and key:
        kind = "plaintext string (not yet migrated)"
    else:
        kind = "missing/empty"
    record("creds", "gemini_api_key storage form", "INFO", kind)
    flags = {k: data.get(k) for k in ("wake_word_enabled", "push_to_talk_enabled",
                                      "input_device", "output_device", "os_system")}
    record("creds", "settings that gate the microphone (values, no secrets)", "INFO",
           json.dumps(flags), gates=flags)


# ── 6. Network & provider ───────────────────────────────────────────────────
HOST = "generativelanguage.googleapis.com"


def check_network() -> None:
    try:
        t0 = time.monotonic()
        infos = socket.getaddrinfo(HOST, 443, proto=socket.IPPROTO_TCP)
        record("net", f"DNS resolve {HOST}", "PASS",
               f"{len(infos)} address(es) in {time.monotonic() - t0:.2f}s")
    except Exception as exc:
        record("net", f"DNS resolve {HOST}", "FAIL", f"{type(exc).__name__}: {_short(exc)}")
        return
    try:
        t0 = time.monotonic()
        with socket.create_connection((HOST, 443), timeout=10) as raw:
            record("net", "TCP connect :443", "PASS", f"{time.monotonic() - t0:.2f}s")
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(raw, server_hostname=HOST) as tls:
                record("net", "TLS handshake", "PASS", f"{tls.version()}")
    except Exception as exc:
        record("net", "TCP/TLS to provider", "FAIL", f"{type(exc).__name__}: {_short(exc)}")


def _classify(exc: BaseException) -> tuple[str, str]:
    """Classify by exception TYPE/CODE, never by substring of str(exc)."""
    if isinstance(exc, BaseExceptionGroup):
        inner = exc.exceptions[0] if exc.exceptions else exc
        return _classify(inner)
    try:
        from google.genai import errors
        if isinstance(exc, errors.APIError):
            code = getattr(exc, "code", None)
            status = getattr(exc, "status", None)
            msg = str(getattr(exc, "message", "") or exc)
            if "api key" in msg.lower() and "not valid" in msg.lower():
                return "AUTH_INVALID_KEY", f"code={code} status={status} (HTTP 400 INVALID_ARGUMENT can mean a bad key)"
            if code in (401, 403):
                return "AUTH_FORBIDDEN", f"code={code} status={status}"
            if code == 404:
                return "MODEL_NOT_FOUND", f"code={code} status={status}"
            if code == 429:
                return "QUOTA", f"code={code} status={status}"
            return "API_ERROR", f"code={code} status={status} {_short(msg, 140)}"
    except Exception:
        pass
    if isinstance(exc, (socket.gaierror, ConnectionError, TimeoutError, asyncio.TimeoutError, OSError)):
        return "NETWORK", f"{type(exc).__name__}: {_short(exc, 140)}"
    return "OTHER", f"{type(exc).__name__}: {_short(exc, 160)}"


async def _live_probe(api_key: str, model: str, version: str) -> tuple[str, str]:
    from google import genai
    client = genai.Client(api_key=api_key, http_options={"api_version": version})
    try:
        async with asyncio.timeout(20):
            async with client.aio.live.connect(model=model, config={"response_modalities": ["AUDIO"]}):
                return "OK", "session opened and closed (no audio sent)"
    except BaseException as exc:  # noqa: BLE001 - we classify everything
        return _classify(exc)


def check_provider(enabled: bool) -> None:
    if not enabled:
        record("provider", "REST + Live connect with configured key", "SKIPPED", "use --provider")
        return
    print("   NOTICE: contacting Google with your configured key (no audio, no personal data sent)")
    try:
        from memory.config_manager import get_gemini_key  # may apply documented credential recovery
        key = get_gemini_key()
    except Exception as exc:
        record("provider", "read credential", "FAIL", f"{type(exc).__name__}")
        return
    if not key:
        record("provider", "read credential", "FAIL", "no key configured")
        return
    looks = key.startswith("AIza") and len(key) == 39
    record("provider", "key format looks like a Google API key", "PASS" if looks else "FAIL",
           f"length={len(key)} (value never printed)")
    try:
        from google import genai
        client = genai.Client(api_key=key)
        next(iter(client.models.list(config={"page_size": 1})), None)
        record("provider", "REST models.list", "PASS", "key accepted over REST")
    except BaseException as exc:  # noqa: BLE001
        cls, detail = _classify(exc)
        record("provider", "REST models.list", "FAIL", f"{cls}: {detail}", classification=cls)
    model = os.environ.get("JARVIS_LIVE_MODEL", "models/gemini-3.1-flash-live-preview")
    for version in ("v1beta", "v1alpha"):
        cls, detail = asyncio.run(_live_probe(key, model, version))
        record("provider", f"Live connect {version} model={model}",
               "PASS" if cls == "OK" else "FAIL", f"{cls}: {detail}", classification=cls)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--mic-test", type=float, default=0, metavar="SECONDS")
    p.add_argument("--mic-device", default=None, help="sounddevice index or name; default = system default")
    p.add_argument("--speaker-test", action="store_true")
    p.add_argument("--hotkey-test", action="store_true")
    p.add_argument("--pip-dry-run", action="store_true")
    p.add_argument("--provider", action="store_true")
    p.add_argument("--out", default="phase1_evidence.json")
    args = p.parse_args(argv)
    device = args.mic_device
    if isinstance(device, str) and device.isdigit():
        device = int(device)

    check_environment()
    check_wake_word(args.pip_dry_run)
    check_audio(args.mic_test, device, args.speaker_test)
    check_hotkey(args.hotkey_test)
    check_credentials()
    check_network()
    check_provider(args.provider)

    Path(args.out).write_text(json.dumps(RESULTS, indent=2), encoding="utf-8")
    print(f"\nEvidence written to {args.out} (contains no credentials). Share that file.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
